###JKMusicPlayer

### Features
* Listen to music
* Manage the queue and shuffle/ repeat mode
* Change colors of the app
* Manage folders to exclude(hide)
* Browse/ Sort/ Search albums and artists
* Change between Dark and Light Modes
* Create playlists by long pressing on music

### Working on
* UI improvements
* Performance improvements


